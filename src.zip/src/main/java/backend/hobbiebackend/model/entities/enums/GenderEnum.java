package backend.hobbiebackend.model.entities.enums;

public enum GenderEnum {
    MALE, FEMALE, OTHER;
}
