package backend.hobbiebackend.service;

import backend.hobbiebackend.model.entities.Test;

public interface TestService {
    void saveTestResults(Test results);

}
